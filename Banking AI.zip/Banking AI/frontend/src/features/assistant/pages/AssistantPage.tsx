import React, { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { PageHeader } from '@/components/ui/PageHeader';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Badge } from '@/components/ui/Badge';
import { Bot, Send, Sparkles, User, HelpCircle } from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

export const AssistantPage: React.FC = () => {
  const { user } = useAuth();
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'assistant',
      text: `Hello ${user?.fullName || 'Customer'}! I am your Aethel Banking Copilot. I can help answer questions about your account status, explain transfer limits, or guide you through deposits and transaction history.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const quickPrompts = [
    'How do I transfer money to another account?',
    'What is the daily wire limit?',
    'How do I deposit funds?',
    'Is my account balance updated in real-time?',
  ];

  const handleSend = (textToSend?: string) => {
    const text = (textToSend || input).trim();
    if (!text) return;

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInput('');

    // Generate intelligent banking-aware assistant response
    setTimeout(() => {
      let reply = "I'm your assistant! For live account balance and statement records, check your 'Dashboard' or 'Transaction History' tab.";

      const lower = text.toLowerCase();
      if (lower.includes('transfer') || lower.includes('send')) {
        reply = `To send funds, visit the "Send Money" tab (/transfers). Enter the recipient's account number (e.g. ACC-xxxx), click "VERIFY" to confirm their name, enter your amount, and confirm the transfer.`;
      } else if (lower.includes('limit') || lower.includes('cap')) {
        reply = "Our real-time transaction engine supports instant RTGS settlement up to ₹10,00,000 per transaction with two-phase commit isolation.";
      } else if (lower.includes('deposit') || lower.includes('add')) {
        reply = "You can deposit cash instantly into your account from the Dashboard or Accounts page by clicking 'Add Funds' or 'Deposit'.";
      } else if (lower.includes('real-time') || lower.includes('updated')) {
        reply = "Yes! All transactions use ACID-compliant database locking, meaning both accounts reflect updated balances immediately.";
      }

      const assistantMsg: ChatMessage = {
        id: `a-${Date.now()}`,
        sender: 'assistant',
        text: reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, assistantMsg]);
    }, 600);
  };

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <PageHeader
        index="[06]"
        tag="INTELLIGENT AGENT"
        title="FINANCIAL ASSISTANT"
        subtitle="AI COPILOT FOR LEDGER INQUIRIES, TRANSFER GUIDANCE & FAQS"
        statusBadge={
          <Badge variant="accent" size="sm" className="flex items-center gap-1">
            <Sparkles className="w-3 h-3" />
            <span>COPILOT ONLINE</span>
          </Badge>
        }
      />

      <Card withCrosshairs className="p-0 overflow-hidden flex flex-col h-[560px]">
        {/* Chat message history */}
        <div className="flex-1 p-5 overflow-y-auto space-y-4 bg-background/50">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex items-start gap-3 ${
                m.sender === 'user' ? 'flex-row-reverse' : ''
              }`}
            >
              <div
                className={`w-7 h-7 rounded-sm flex items-center justify-center shrink-0 text-xs font-bold ${
                  m.sender === 'user'
                    ? 'bg-accent text-background'
                    : 'bg-background-elevated border border-border text-accent'
                }`}
              >
                {m.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div
                className={`max-w-[75%] p-3.5 rounded-sm text-xs font-mono leading-relaxed ${
                  m.sender === 'user'
                    ? 'bg-accent/15 border border-accent/30 text-foreground'
                    : 'bg-background-elevated border border-border text-foreground'
                }`}
              >
                <p>{m.text}</p>
                <span className="block text-[9px] text-foreground-muted text-right mt-1.5">
                  {m.timestamp}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Quick Question Chips */}
        <div className="p-3 bg-background-secondary/60 border-t border-border flex flex-wrap gap-2">
          {quickPrompts.map((q, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleSend(q)}
              className="px-2.5 py-1 text-[11px] font-mono rounded-sm border border-border hover:border-accent hover:text-accent transition-colors bg-background-elevated text-foreground-secondary flex items-center gap-1"
            >
              <HelpCircle className="w-3 h-3" />
              <span>{q}</span>
            </button>
          ))}
        </div>

        {/* Chat input box */}
        <div className="p-4 border-t border-border bg-background flex items-center gap-2">
          <Input
            placeholder="Ask about transfers, deposits, or account operations..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSend();
            }}
            isMonospace
            className="flex-1"
          />
          <Button
            variant="primary"
            size="md"
            onClick={() => handleSend()}
            disabled={!input.trim()}
            rightIcon={<Send className="w-4 h-4" />}
          >
            SEND
          </Button>
        </div>
      </Card>
    </div>
  );
};


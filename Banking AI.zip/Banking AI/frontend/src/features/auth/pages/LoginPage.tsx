import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { PasswordInput } from '@/components/ui/PasswordInput';
import { Button } from '@/components/ui/Button';
import { toast } from 'sonner';
import { Shield, Sparkles, UserCheck } from 'lucide-react';

const loginSchema = z.object({
  username: z.string().min(1, 'Please enter a username or email address'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
});

type LoginFormData = z.infer<typeof loginSchema>;

export const LoginPage: React.FC = () => {
  const { login, setDemoUser } = useAuth();
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: '',
      password: '',
    },
  });

  const onSubmit = async (data: LoginFormData) => {
    setIsSubmitting(true);
    try {
      await login(data);
      toast.success('Session verified. Welcome to Aethel Banking.');
      navigate('/dashboard');
    } catch (err: unknown) {
      const error = err as Error;
      toast.error(error.message || 'Authentication failed. Please verify credentials.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleQuickDemo = (role: 'ROLE_CUSTOMER' | 'ROLE_ADMIN') => {
    setDemoUser(role);
    toast.success(`Demo ${role === 'ROLE_ADMIN' ? 'Admin' : 'Customer'} session loaded`);
    navigate(role === 'ROLE_ADMIN' ? '/admin/dashboard' : '/dashboard');
  };

  return (
    <div className="min-h-[82vh] flex items-center justify-center py-10 px-4">
      <div className="w-full max-w-md space-y-6">
        {/* Editorial Brand Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-background-elevated border border-border rounded-sm text-xs font-mono text-accent">
            <span className="w-1.5 h-1.5 bg-accent rounded-full animate-pulse" />
            <span>[AUTH.PROTOCOL] AES-256</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-heading font-extrabold uppercase tracking-tight text-foreground">
            ACCESS TERMINAL
          </h1>
          <p className="text-xs font-mono text-foreground-secondary">
            ENTER ENCRYPTED CREDENTIALS TO INITIALIZE BANKING SESSION
          </p>
        </div>

        {/* Login Card */}
        <Card withCrosshairs variant="elevated" className="border-border-strong">
          <CardHeader>
            <CardTitle>
              <Shield className="w-4 h-4 text-accent" />
              <span>AUTHENTICATION</span>
            </CardTitle>
            <CardDescription>// VERIFY IDENTITY</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <Input
                label="Username / Registered Email"
                placeholder="customer@domain.com"
                {...register('username')}
                error={errors.username?.message}
                isMonospace
              />

              <PasswordInput
                label="Access Password"
                placeholder="••••••••••••"
                {...register('password')}
                error={errors.password?.message}
              />

              <div className="pt-2">
                <Button
                  type="submit"
                  variant="primary"
                  className="w-full"
                  isLoading={isSubmitting}
                >
                  INITIALIZE SESSION
                </Button>
              </div>
            </form>

            {/* Quick Demo Access Helpers */}
            <div className="mt-6 pt-5 border-t border-border">
              <div className="flex items-center justify-between mb-3 text-[11px] font-mono text-foreground-muted">
                <span className="flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-accent" />
                  <span>ONE-CLICK DEMO SESSIONS:</span>
                </span>
                <span className="text-accent">[DEV SHORTCUT]</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  className="text-xs font-mono"
                  onClick={() => handleQuickDemo('ROLE_CUSTOMER')}
                  leftIcon={<UserCheck className="w-3.5 h-3.5 text-accent" />}
                >
                  DEMO CUSTOMER
                </Button>
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  className="text-xs font-mono"
                  onClick={() => handleQuickDemo('ROLE_ADMIN')}
                  leftIcon={<Shield className="w-3.5 h-3.5 text-status-warning" />}
                >
                  DEMO ADMIN
                </Button>
              </div>
            </div>

            {/* Register link */}
            <div className="mt-5 text-center text-xs font-mono text-foreground-secondary">
              Need a new account?{' '}
              <Link to="/register" className="text-accent hover:underline font-semibold">
                Open banking account &gt;
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

package in.ashish.combined.controller;

import in.ashish.combined.dto.TransferRequest;
import in.ashish.combined.dto.TransferResponse;
import in.ashish.combined.service.TransferService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST Controller exposing Money Transfer APIs.
 *
 * Base Path: /api/transfers
 *
 * Interview Concepts:
 * - Atomic Money Transfer: Guarantees that neither party is debited without the other being credited.
 * - HTTP Status Codes:
 *     200 OK: Transfer completed successfully.
 *     400 Bad Request: Triggered by invalid IDs, same account transfer, negative amounts, or insufficient funds.
 *     404 Not Found: Source or Destination account not found.
 */
@Slf4j
@RestController
@RequestMapping("/api/transfers")
@RequiredArgsConstructor
public class TransferController {

    private final TransferService transferService;

    /**
     * Transfer funds between two bank accounts.
     * POST /api/transfers
     * Status: 200 OK on success, 400 Bad Request on validation/business failure, 404 Not Found if account missing.
     */
    @PostMapping
    public ResponseEntity<TransferResponse> transferMoney(@Valid @RequestBody TransferRequest request) {
        log.info("REST request to transfer ₹{} from account ID {} to account ID {}",
                request.getAmount(), request.getSourceAccountId(), request.getDestinationAccountId());
        TransferResponse response = transferService.transferMoney(request);
        return ResponseEntity.ok(response);
    }
}
